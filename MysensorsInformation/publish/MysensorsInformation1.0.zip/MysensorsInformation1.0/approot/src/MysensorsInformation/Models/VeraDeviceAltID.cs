﻿namespace MysensorListener.Models
{
    public class VeraDeviceAltID
    {
        public long NodeID { get; set; }
        public long ChildID { get; set; }
    }
}
