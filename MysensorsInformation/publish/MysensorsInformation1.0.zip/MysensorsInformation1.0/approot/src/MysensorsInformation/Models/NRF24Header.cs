﻿namespace MysensorListener.Models
{
    public class NRF24Header
    {
        public string Timestamp { get; set; }
        public string PacketsLost { get; set; }
        public string Address { get; set; }
    }
}
