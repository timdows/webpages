﻿namespace MysensorListener.Models
{
    public class VeraRoom
    {
        public long ID { get; set; }
        public string Name { get; set; }
    }
}
