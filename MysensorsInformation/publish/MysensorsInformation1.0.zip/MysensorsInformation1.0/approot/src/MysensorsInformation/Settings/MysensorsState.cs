﻿namespace MysensorListener.Settings
{
    public class MysensorsState : BaseState
    {

    }
}
